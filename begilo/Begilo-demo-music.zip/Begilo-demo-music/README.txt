Begilo demo music (for App Review and first-run testing)

J. S. Bach, Goldberg Variations, BWV 988
Performed by Kimiko Ishizaka, "Open Goldberg Variations" project (2012)

Composition: public domain. Recording: released by the performer under
CC0 1.0 Universal (public domain dedication), per Wikimedia Commons:
https://creativecommons.org/publicdomain/zero/1.0/
Source: https://commons.wikimedia.org/wiki/Category:Open_Goldberg_Variations
No attribution is required; it is given here as a courtesy.

Files were converted from Ogg Vorbis to AAC (.m4a) for import into Begilo.
